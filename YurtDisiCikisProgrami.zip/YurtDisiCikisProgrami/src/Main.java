/**
 *
 * @author tugba
 */
public class Main 
{
    public static void main(String[] args) throws InterruptedException 
    {
        System.out.print("Sabiha Gökçen Havalimanına Hoşgeldiniz...");
        
        String sartlar = "Yurtdışı Çıkış Kuralları...\n"
                        +"Herhangi bir siyasi yasağınınızın bulunmaması gerekiyor...\n "
                        +"15 TL harç bedelini tam olarak yatırmanız gerekiyor...\n"
                        +"Gideceğiniz ülkeye vizenizin bulunması gerekiyor...";
        
        String message = "Yurt dışı şartlarından hepsini sağlamanız gerekiyor.";
        
        while(true) 
        {
            System.out.println("************************************");
            System.out.println(sartlar);
            System.out.println("************************************");
                        
            Yolcu yolcu = new Yolcu();
            
            System.out.println("Harç Bedeli Kontrol Ediliyor...");
            
            Thread.sleep(3000); // Programımız : 3000 milisaniye 3sn  bekletiliyor.
            
            if(yolcu.yurtdisiHarciKontrol() == false)
            {
                System.out.println(message);
                continue;
            }
            
            System.out.println("Siyasi Yasak Kontrol Ediliyor...");
            Thread.sleep(3000);
            
            if(yolcu.siyasiYasakKontrol() == false)
            {
                System.out.println(message);
                continue;
            }
            
            System.out.println("Vize Durumu Kontrol Ediliyor...");
            Thread.sleep(3000);
            
            if(yolcu.vizeDurumuKontrol() == false)
            {
                System.out.println(message);
                continue;
            }
            System.out.println("İşlemleriniz Tamam ! Yurt Dışına Çıkabilirsiniz...");
            break;
            
        }
    }
    
}
