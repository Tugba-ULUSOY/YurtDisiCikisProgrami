/**
 *
 * @author tugba
 */
public interface YurtDisiKurallari 
{
    boolean yurtdisiHarciKontrol();
    boolean siyasiYasakKontrol();
    boolean vizeDurumuKontrol();
}
